import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Layout from "./components/Layout";
import Recipes from "./components/Recipes";
import CreateRecipe from "./components/CreateRecipe";
import EditRecipe from "./components/EditRecipe";
import SearchRecipes from "./components/SearchRecipes";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout children={<Recipes />} />,

    errorElement: <div>Not Found</div>,
  },
  {
    path: "/recipes/create",
    element: <Layout children={<CreateRecipe />} />,
  },
  {
    path: "/recipes/:id",
    element: <Layout children={<EditRecipe />} />,
  },
  {
    path: "/search/:search",
    element: <Layout children={<SearchRecipes />} />,
  },
  {
    path: "/recipes/:id/edit",
    element: <h1>Edit Recipe</h1>,
  },
  {
    path: "/recipes/new",
    element: <h1>New Recipe</h1>,
  },
]);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
