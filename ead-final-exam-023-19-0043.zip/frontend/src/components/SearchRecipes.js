import { Typography } from "@mui/material";
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import * as React from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import Divider from "@mui/material/Divider";
import ListItemText from "@mui/material/ListItemText";
import { ImageListItemBar, ListItemButton } from "@mui/material";
import { ImageListItem } from "@mui/material";
import { Link } from "@mui/material";
import Button from "@mui/material/Button";

import { Box } from "@mui/material";

const SearchRecipes = () => {
  const { search } = useParams();
  const [loading, setLoading] = useState(false);
  const [recipes, setRecipes] = useState([]);
  useEffect(() => {
    const fetchRecipes = async () => {
      console.log(search);
      setLoading(true);
      fetch(`http://localhost:4000/search/${search}`)
        .then((response) => {
          console.log(response);
          return response.json();
        })
        .then((data) => {
          console.log(data);
          setRecipes(data);
          setLoading(false);
        });
      fetchRecipes();
    };
  }, [search]);
  if (loading) return "Loading...";
  const handleDelete = async (id) => {
    const response = await fetch(`http://localhost:4000/recipes/${id}`, {
      method: "DELETE",
    });
    const data = await response.json();
    console.log(data);
    setRecipes(recipes.filter((recipe) => recipe.id !== id));
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        width: "100%",
        marginTop: "2%",
        marginBottom: "2%",
        marginLeft: "10%",
      }}
    >
      <List
        sx={{
          width: "100%",
          maxWidth: "100%",
          marginRight: "10%",
          bgcolor: "background.paper",
        }}
      >
        {recipes.length === 0 ? (
          <Typography variant="h4">No recipes found!</Typography>
        ) : (
          recipes.map((recipe) => (
            <div key={recipe.id}>
              <ListItem alignItems="flex-start" width="100%">
                <ImageListItem key={recipe?.imageName}>
                  <img
                    src={`${"/public/logo192.png"}?w=248&fit=crop&auto=format`}
                    srcSet={`${recipe?.img}?w=248&fit=crop&auto=format&dpr=2 2x`}
                    alt={recipe.title}
                    loading="lazy"
                  />
                  <ImageListItemBar position="below" title={recipe?.author} />
                </ImageListItem>
                <ListItemText
                  primary={recipe.title}
                  secondary={
                    <React.Fragment>
                      <Typography
                        sx={{ display: "inline" }}
                        component="span"
                        variant="body2"
                        color="text.primary"
                      >
                        {recipe.description}
                      </Typography>
                      {recipe.ingredients}
                    </React.Fragment>
                  }
                />
                {/* add Edit Button */}
                <ListItemButton
                  component={Link}
                  to={`/recipes/${recipe["_id"]}`}
                >
                  Edit
                </ListItemButton>
                <ListItemButton
                  component={Button}
                  onClick={async () => await handleDelete(recipe["_id"])}
                  to={`/recipes/${recipe["_id"]}`}
                >
                  Delete
                </ListItemButton>
              </ListItem>
            </div>
          ))
        )}
      </List>
    </Box>
  );
};

export default SearchRecipes;
