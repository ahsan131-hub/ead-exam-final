import Navbar from "./Navbar";
import { Grid } from "@mui/material";

function Layout({ children }) {
  return (
    <Grid spacing={2}>
      <Navbar />
      {children}
    </Grid>
  );
}

export default Layout;
