import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import { Box, OutlinedInput, Typography } from "@mui/material";
import { Button } from "@mui/material";
import { useEffect, useState } from "react";
import { Routes, Route, useParams } from "react-router-dom";
import Recipes from "./Recipes";

const EditRecipe = () => {
  let { id } = useParams();
  const [loading, setLoading] = useState(true);

  const [recipe, setRecipe] = useState({
    title: "",
    description: "",
    ingredients: "",
    instructions: "",
    image: "",
  });
  useEffect(() => {
    const fetchRecipe = async () => {
      const response = await fetch(`http://localhost:4000/recipes/${id}`);
      const data = await response.json();
      setRecipe(data);
    };
    fetchRecipe();
    setLoading(false);
  }, [id]);

  const handleChange = (event) => {
    setRecipe({
      ...recipe,
      [event.target.name]: event.target.value,
    });
  };

  const onSubmit = async (event) => {
    event.preventDefault();
    const { title, ingredients, instructions, description } = recipe;
    console.log(recipe);
    setLoading(true);
    const response = await fetch(`http://localhost:4000/recipes/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        title,
        ingredients,
        instructions,
        description,
      }),
    });
    const data = await response.json();
    setLoading(false);
    console.log(data);
  };

  return (
    <>
      {loading ? (
        <Typography variant="h4">Loading...</Typography>
      ) : (
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            width: "100%",
            marginTop: "2%",
            marginBottom: "2%",
            marginLeft: "10%",
          }}
        >
          <Typography variant="h4">Update Recipe</Typography>
          <form
            onSubmit={onSubmit}
            style={{
              display: "flex",

              flexDirection: "column",
              justifyContent: "center",
              width: "100%",
              marginTop: "2%",
            }}
          >
            <FormControl sx={{ m: 1, width: "25%" }} variant="outlined">
              <InputLabel htmlFor="component-outlined">Title</InputLabel>
              <OutlinedInput
                id="component-outlined"
                value={recipe.title}
                name="title"
                onChange={handleChange}
                label="Title"
              />
            </FormControl>
            <FormControl sx={{ m: 1, width: "25%" }} variant="outlined">
              <InputLabel htmlFor="component-outlined">Description</InputLabel>
              <OutlinedInput
                id="component-outlined"
                value={recipe.description}
                name="description"
                onChange={handleChange}
                label="Description"
              />
            </FormControl>
            <FormControl sx={{ m: 1, width: "25%" }} variant="outlined">
              <InputLabel htmlFor="component-outlined">Ingredients</InputLabel>
              <OutlinedInput
                id="component-outlined"
                value={recipe.ingredients}
                name="ingredients"
                onChange={handleChange}
                label="Ingredients"
              />
            </FormControl>
            <FormControl sx={{ m: 1, width: "25%" }} variant="outlined">
              <InputLabel htmlFor="component-outlined">Instructions</InputLabel>
              <OutlinedInput
                id="component-outlined"
                value={recipe.instructions}
                name="instructions"
                onChange={handleChange}
                label="Instructions"
              />
            </FormControl>
            <FormControl sx={{ m: 1, width: "25%" }} variant="outlined">
              <Button variant="contained" component="label">
                Upload File
                <input type="file" hidden />
              </Button>
            </FormControl>
            <FormControl sx={{ m: 1, width: "25%" }} variant="outlined">
              <button
                type="submit"
                style={{
                  backgroundColor: "#4CAF50",
                  color: "white",
                  padding: "14px 20px",
                  margin: "8px 0",
                  border: "none",
                  cursor: "pointer",
                  width: "100%",
                  borderRadius: "4px",
                  fontSize: "16px",
                  fontWeight: "bold",
                }}
              >
                Update Recipes
              </button>
            </FormControl>
          </form>
        </Box>
      )}
    </>
  );
};
export default EditRecipe;
