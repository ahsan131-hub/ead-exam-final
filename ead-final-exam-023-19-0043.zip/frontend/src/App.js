import Navbar from "./components/Navbar";
import { Grid } from "@mui/material";
import Container from "@mui/material/Container";
import CreateRecipe from "./components/CreateRecipe";
function App() {
  return (
    <Grid spacing={2}>
      <Navbar />
      <CreateRecipe />
    </Grid>
  );
}

export default App;
